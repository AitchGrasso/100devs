//create a function that adds two numbers and alerts the sum
function addTwoNumbers(num1, num2){
    let sum = num1 + num2
    alert(sum)
}
addTwoNumbers(2, 3)
//create a function that multiplys three numbers and console logs the product
function multiplyThreeNumbers(num1, num2, num3){
    const product = num1 * num2 * num3
    console.log(product)
}
multiplyThreeNumbers(5, 6, 7)

//create a function that divides two numbers and returns the ???
function dividesTwoNumbers(num1, num2){
    return n1 / n2
}
console.log(dividesTwoNumbers(24, 12))