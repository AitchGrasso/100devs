//Write your pseduo code first! 
//0 + 32
document.querySelector('#convert').addEventListener('click', convert)

function convert() {
    //need value in celsius
    let temp = document.querySelector('#celsius').value

    //convert from celsius to fairenheit
    temp = temp * 9/5 + 32

    //show it
    document.querySelector('#convertDisplay').innerText = temp
  
}

