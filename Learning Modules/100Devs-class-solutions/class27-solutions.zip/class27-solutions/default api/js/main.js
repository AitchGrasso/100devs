//Example fetch using pokemonapi.co
document.querySelector('button').addEventListener('click', getFetch)

function getFetch(){
  // const choice = document.querySelector('input').string
  // console.log(choice)
  const url = "https://app.pixelencounter.com/api/basic/svgmonsters?primaryColor=string"

  fetch(url)
      .then(res => res.json()) // parse response as JSON
      .then(data => {
        console.log(data)
        // document.querySelector('h3').src = data.

        // document.querySelector('h2').innerText = data.name
        // document.querySelector('h3').innerText = data.htmlCode
        // document.querySelector('h4').innerText = data.unicode
      })
      .catch(err => {
          console.log(`error ${err}`)
      });
}

